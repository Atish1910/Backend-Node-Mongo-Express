const runtime = () => {
  // console.log(x);
  let num = 98;
  num();
};

module.exports = runtime;