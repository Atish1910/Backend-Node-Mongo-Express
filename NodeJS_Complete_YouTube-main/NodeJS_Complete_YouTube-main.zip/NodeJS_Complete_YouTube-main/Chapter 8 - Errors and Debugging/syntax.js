const testingSyntax = () => {
  console.log("I am inside testing syntax")
};

module.exports = testingSyntax;