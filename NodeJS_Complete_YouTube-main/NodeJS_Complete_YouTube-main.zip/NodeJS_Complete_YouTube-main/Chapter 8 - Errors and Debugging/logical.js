const logical = () => {
  let num = 5;
  if (num = 10) {
    console.log(num);
  } else {
    console.log("num is not 10");
  }


  
};

module.exports = logical;